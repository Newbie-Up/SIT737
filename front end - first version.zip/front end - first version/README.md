Installation
use NPM to install the dependencies.

$ npm install
Usage
The project can be run with

npm start
The project can be viewed in the browser at

http://localhost:2333